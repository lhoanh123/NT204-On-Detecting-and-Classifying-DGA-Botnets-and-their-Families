from tensorflow.keras.models import load_model
from tensorflow.keras.initializers import Orthogonal
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from keras_self_attention import SeqSelfAttention, SeqWeightedAttention

import numpy as np
import string
from flask import Flask, request, render_template
import h5py
import pandas as pd

# Khởi tạo ứng dụng Flask
app = Flask(__name__)

# Đọc dữ liệu từ tệp CSV
df = pd.read_csv('dataset_all.csv')

# Lấy số lượng domain theo từng lớp
domain_count_per_class = df.groupby('class')['domain'].nunique().reset_index(name='count')

# Lấy mẫu dữ liệu
sampled_data = pd.DataFrame()
for class_name in domain_count_per_class['class']:
    class_data = df[df['class'] == class_name].sample(frac=0.1, random_state=42)
    sampled_data = pd.concat([sampled_data, class_data])

# Khởi tạo Tokenizer và huấn luyện nó trên các tên miền
tokenizer = Tokenizer(char_level=True)  # Mã hóa ký tự
tokenizer.fit_on_texts(sampled_data['domain'])
#sequences = tokenizer.texts_to_sequences(sampled_data['domain'])

# Xác định độ dài tối đa của chuỗi
#max_len = 73

# Đăng ký các đối tượng tùy chỉnh
def custom_objects_initializer():
    return {
        'Orthogonal': Orthogonal,
        'SeqSelfAttention': SeqSelfAttention,
        'SeqWeightedAttention': SeqWeightedAttention
    }

# Hàm để loại bỏ tham số 'time_major' khỏi cấu hình lớp LSTM
def remove_time_major(model_path):
    with h5py.File(model_path, 'r+') as f:
        model_config = f.attrs['model_config']
        if isinstance(model_config, bytes):
            model_config = model_config.decode('utf-8')
        model_config = model_config.replace('"time_major": false, ', '')
        f.attrs['model_config'] = model_config.encode('utf-8')

# Loại bỏ tham số 'time_major' từ cấu hình mô hình
remove_time_major(r'AADR_La_bin07.h5')
remove_time_major(r'la_mul07_model.h5')

# Tải mô hình với các đối tượng tùy chỉnh
modelBin = load_model(r'AADR_La_bin07.h5', custom_objects=custom_objects_initializer())
modelMul = load_model(r'la_mul07_model.h5', custom_objects=custom_objects_initializer())
custom_mapping = {
    0: 'conficker',
    1: 'cryptolocker',
    2: 'zeus',
    3: 'pushdo',
    4: 'rovnix',
    5: 'tinba',
    6: 'matsnu',
    7: 'ramdo'
}
# Hàm tiền xử lý domain
def preprocess_domain(domain, max_len):
    # Chuyển đổi domain thành chuỗi số và padding
    sequence = tokenizer.texts_to_sequences([domain])
    padded_sequence = pad_sequences(sequence, maxlen=max_len)
    return padded_sequence

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    domain = request.form['domain']
    input_data = preprocess_domain(domain, 73)    
    prediction = modelBin.predict(input_data)
    family ='no'
    if prediction[0] < 0.5:
        result = 'legit'
    else:
        result = 'malicious'
        input_data1 = preprocess_domain(domain, 40)
        predictionFamily = modelMul.predict(input_data1)
        predicted_classes = np.argmax(predictionFamily, axis=1)[0]
        predicted_families = custom_mapping[predicted_classes]
        family = predicted_families
    #result = 'legit' if prediction[0] < 0.5 else 'không legit'

    return render_template('result.html', domain=domain, result=result, family=family)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')

